/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "F:/verilog/P5_new/stall.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};



static void Cont_30_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 1812U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(30, ng0);
    t2 = (t0 + 1288);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = (t0 + 2348);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 1U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 0);
    t18 = (t0 + 2296);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Initial_31_1(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(32, ng0);

LAB2:    xsi_set_current_line(33, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 1288);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 1);

LAB1:    return;
}

static void Always_35_2(char *t0)
{
    char t7[8];
    char t8[8];
    char t12[8];
    char t27[8];
    char t42[8];
    char t58[8];
    char t73[8];
    char t81[8];
    char t109[8];
    char t117[8];
    char t149[8];
    char t163[8];
    char t179[8];
    char t187[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t9;
    char *t10;
    char *t11;
    char *t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    char *t19;
    char *t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;
    char *t25;
    char *t26;
    char *t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    char *t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    char *t49;
    char *t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    char *t55;
    char *t56;
    char *t57;
    char *t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    unsigned int t70;
    unsigned int t71;
    char *t72;
    char *t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    unsigned int t79;
    char *t80;
    unsigned int t82;
    unsigned int t83;
    unsigned int t84;
    char *t85;
    char *t86;
    char *t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    char *t95;
    char *t96;
    unsigned int t97;
    unsigned int t98;
    unsigned int t99;
    int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    int t104;
    unsigned int t105;
    unsigned int t106;
    unsigned int t107;
    unsigned int t108;
    char *t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    char *t116;
    unsigned int t118;
    unsigned int t119;
    unsigned int t120;
    char *t121;
    char *t122;
    char *t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    unsigned int t129;
    unsigned int t130;
    char *t131;
    char *t132;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    unsigned int t136;
    unsigned int t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    int t141;
    int t142;
    unsigned int t143;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    unsigned int t147;
    unsigned int t148;
    char *t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    char *t156;
    char *t157;
    unsigned int t158;
    unsigned int t159;
    unsigned int t160;
    char *t161;
    char *t162;
    char *t164;
    char *t165;
    unsigned int t166;
    unsigned int t167;
    unsigned int t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t173;
    unsigned int t174;
    unsigned int t175;
    unsigned int t176;
    unsigned int t177;
    char *t178;
    char *t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    unsigned int t185;
    char *t186;
    unsigned int t188;
    unsigned int t189;
    unsigned int t190;
    char *t191;
    char *t192;
    char *t193;
    unsigned int t194;
    unsigned int t195;
    unsigned int t196;
    unsigned int t197;
    unsigned int t198;
    unsigned int t199;
    unsigned int t200;
    char *t201;
    char *t202;
    unsigned int t203;
    unsigned int t204;
    unsigned int t205;
    unsigned int t206;
    unsigned int t207;
    unsigned int t208;
    unsigned int t209;
    unsigned int t210;
    int t211;
    int t212;
    unsigned int t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    unsigned int t217;
    unsigned int t218;
    char *t219;
    unsigned int t220;
    unsigned int t221;
    unsigned int t222;
    unsigned int t223;
    unsigned int t224;
    char *t225;
    char *t226;

LAB0:    t1 = (t0 + 2100U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(35, ng0);
    t2 = (t0 + 2304);
    *((int *)t2) = 1;
    t3 = (t0 + 2128);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(36, ng0);

LAB5:    xsi_set_current_line(40, ng0);
    t4 = (t0 + 600U);
    t5 = *((char **)t4);
    t4 = (t0 + 692U);
    t6 = *((char **)t4);
    memset(t7, 0, 8);
    xsi_vlog_unsigned_minus(t7, 32, t5, 2, t6, 2);
    t4 = ((char*)((ng1)));
    memset(t8, 0, 8);
    t9 = (t7 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB7;

LAB6:    t10 = (t4 + 4);
    if (*((unsigned int *)t10) != 0)
        goto LAB7;

LAB10:    if (*((unsigned int *)t7) > *((unsigned int *)t4))
        goto LAB8;

LAB9:    memset(t12, 0, 8);
    t13 = (t8 + 4);
    t14 = *((unsigned int *)t13);
    t15 = (~(t14));
    t16 = *((unsigned int *)t8);
    t17 = (t16 & t15);
    t18 = (t17 & 1U);
    if (t18 != 0)
        goto LAB11;

LAB12:    if (*((unsigned int *)t13) != 0)
        goto LAB13;

LAB14:    t20 = (t12 + 4);
    t21 = *((unsigned int *)t12);
    t22 = *((unsigned int *)t20);
    t23 = (t21 || t22);
    if (t23 > 0)
        goto LAB15;

LAB16:    memcpy(t117, t12, 8);

LAB17:    memset(t149, 0, 8);
    t150 = (t117 + 4);
    t151 = *((unsigned int *)t150);
    t152 = (~(t151));
    t153 = *((unsigned int *)t117);
    t154 = (t153 & t152);
    t155 = (t154 & 1U);
    if (t155 != 0)
        goto LAB47;

LAB48:    if (*((unsigned int *)t150) != 0)
        goto LAB49;

LAB50:    t157 = (t149 + 4);
    t158 = *((unsigned int *)t149);
    t159 = *((unsigned int *)t157);
    t160 = (t158 || t159);
    if (t160 > 0)
        goto LAB51;

LAB52:    memcpy(t187, t149, 8);

LAB53:    t219 = (t187 + 4);
    t220 = *((unsigned int *)t219);
    t221 = (~(t220));
    t222 = *((unsigned int *)t187);
    t223 = (t222 & t221);
    t224 = (t223 != 0);
    if (t224 > 0)
        goto LAB65;

LAB66:    xsi_set_current_line(42, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1288);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB67:    goto LAB2;

LAB7:    t11 = (t8 + 4);
    *((unsigned int *)t8) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB9;

LAB8:    *((unsigned int *)t8) = 1;
    goto LAB9;

LAB11:    *((unsigned int *)t12) = 1;
    goto LAB14;

LAB13:    t19 = (t12 + 4);
    *((unsigned int *)t12) = 1;
    *((unsigned int *)t19) = 1;
    goto LAB14;

LAB15:    t24 = (t0 + 784U);
    t25 = *((char **)t24);
    t24 = (t0 + 968U);
    t26 = *((char **)t24);
    memset(t27, 0, 8);
    t24 = (t25 + 4);
    t28 = (t26 + 4);
    t29 = *((unsigned int *)t25);
    t30 = *((unsigned int *)t26);
    t31 = (t29 ^ t30);
    t32 = *((unsigned int *)t24);
    t33 = *((unsigned int *)t28);
    t34 = (t32 ^ t33);
    t35 = (t31 | t34);
    t36 = *((unsigned int *)t24);
    t37 = *((unsigned int *)t28);
    t38 = (t36 | t37);
    t39 = (~(t38));
    t40 = (t35 & t39);
    if (t40 != 0)
        goto LAB21;

LAB18:    if (t38 != 0)
        goto LAB20;

LAB19:    *((unsigned int *)t27) = 1;

LAB21:    memset(t42, 0, 8);
    t43 = (t27 + 4);
    t44 = *((unsigned int *)t43);
    t45 = (~(t44));
    t46 = *((unsigned int *)t27);
    t47 = (t46 & t45);
    t48 = (t47 & 1U);
    if (t48 != 0)
        goto LAB22;

LAB23:    if (*((unsigned int *)t43) != 0)
        goto LAB24;

LAB25:    t50 = (t42 + 4);
    t51 = *((unsigned int *)t42);
    t52 = (!(t51));
    t53 = *((unsigned int *)t50);
    t54 = (t52 || t53);
    if (t54 > 0)
        goto LAB26;

LAB27:    memcpy(t81, t42, 8);

LAB28:    memset(t109, 0, 8);
    t110 = (t81 + 4);
    t111 = *((unsigned int *)t110);
    t112 = (~(t111));
    t113 = *((unsigned int *)t81);
    t114 = (t113 & t112);
    t115 = (t114 & 1U);
    if (t115 != 0)
        goto LAB40;

LAB41:    if (*((unsigned int *)t110) != 0)
        goto LAB42;

LAB43:    t118 = *((unsigned int *)t12);
    t119 = *((unsigned int *)t109);
    t120 = (t118 & t119);
    *((unsigned int *)t117) = t120;
    t121 = (t12 + 4);
    t122 = (t109 + 4);
    t123 = (t117 + 4);
    t124 = *((unsigned int *)t121);
    t125 = *((unsigned int *)t122);
    t126 = (t124 | t125);
    *((unsigned int *)t123) = t126;
    t127 = *((unsigned int *)t123);
    t128 = (t127 != 0);
    if (t128 == 1)
        goto LAB44;

LAB45:
LAB46:    goto LAB17;

LAB20:    t41 = (t27 + 4);
    *((unsigned int *)t27) = 1;
    *((unsigned int *)t41) = 1;
    goto LAB21;

LAB22:    *((unsigned int *)t42) = 1;
    goto LAB25;

LAB24:    t49 = (t42 + 4);
    *((unsigned int *)t42) = 1;
    *((unsigned int *)t49) = 1;
    goto LAB25;

LAB26:    t55 = (t0 + 784U);
    t56 = *((char **)t55);
    t55 = (t0 + 876U);
    t57 = *((char **)t55);
    memset(t58, 0, 8);
    t55 = (t56 + 4);
    t59 = (t57 + 4);
    t60 = *((unsigned int *)t56);
    t61 = *((unsigned int *)t57);
    t62 = (t60 ^ t61);
    t63 = *((unsigned int *)t55);
    t64 = *((unsigned int *)t59);
    t65 = (t63 ^ t64);
    t66 = (t62 | t65);
    t67 = *((unsigned int *)t55);
    t68 = *((unsigned int *)t59);
    t69 = (t67 | t68);
    t70 = (~(t69));
    t71 = (t66 & t70);
    if (t71 != 0)
        goto LAB32;

LAB29:    if (t69 != 0)
        goto LAB31;

LAB30:    *((unsigned int *)t58) = 1;

LAB32:    memset(t73, 0, 8);
    t74 = (t58 + 4);
    t75 = *((unsigned int *)t74);
    t76 = (~(t75));
    t77 = *((unsigned int *)t58);
    t78 = (t77 & t76);
    t79 = (t78 & 1U);
    if (t79 != 0)
        goto LAB33;

LAB34:    if (*((unsigned int *)t74) != 0)
        goto LAB35;

LAB36:    t82 = *((unsigned int *)t42);
    t83 = *((unsigned int *)t73);
    t84 = (t82 | t83);
    *((unsigned int *)t81) = t84;
    t85 = (t42 + 4);
    t86 = (t73 + 4);
    t87 = (t81 + 4);
    t88 = *((unsigned int *)t85);
    t89 = *((unsigned int *)t86);
    t90 = (t88 | t89);
    *((unsigned int *)t87) = t90;
    t91 = *((unsigned int *)t87);
    t92 = (t91 != 0);
    if (t92 == 1)
        goto LAB37;

LAB38:
LAB39:    goto LAB28;

LAB31:    t72 = (t58 + 4);
    *((unsigned int *)t58) = 1;
    *((unsigned int *)t72) = 1;
    goto LAB32;

LAB33:    *((unsigned int *)t73) = 1;
    goto LAB36;

LAB35:    t80 = (t73 + 4);
    *((unsigned int *)t73) = 1;
    *((unsigned int *)t80) = 1;
    goto LAB36;

LAB37:    t93 = *((unsigned int *)t81);
    t94 = *((unsigned int *)t87);
    *((unsigned int *)t81) = (t93 | t94);
    t95 = (t42 + 4);
    t96 = (t73 + 4);
    t97 = *((unsigned int *)t95);
    t98 = (~(t97));
    t99 = *((unsigned int *)t42);
    t100 = (t99 & t98);
    t101 = *((unsigned int *)t96);
    t102 = (~(t101));
    t103 = *((unsigned int *)t73);
    t104 = (t103 & t102);
    t105 = (~(t100));
    t106 = (~(t104));
    t107 = *((unsigned int *)t87);
    *((unsigned int *)t87) = (t107 & t105);
    t108 = *((unsigned int *)t87);
    *((unsigned int *)t87) = (t108 & t106);
    goto LAB39;

LAB40:    *((unsigned int *)t109) = 1;
    goto LAB43;

LAB42:    t116 = (t109 + 4);
    *((unsigned int *)t109) = 1;
    *((unsigned int *)t116) = 1;
    goto LAB43;

LAB44:    t129 = *((unsigned int *)t117);
    t130 = *((unsigned int *)t123);
    *((unsigned int *)t117) = (t129 | t130);
    t131 = (t12 + 4);
    t132 = (t109 + 4);
    t133 = *((unsigned int *)t12);
    t134 = (~(t133));
    t135 = *((unsigned int *)t131);
    t136 = (~(t135));
    t137 = *((unsigned int *)t109);
    t138 = (~(t137));
    t139 = *((unsigned int *)t132);
    t140 = (~(t139));
    t141 = (t134 & t136);
    t142 = (t138 & t140);
    t143 = (~(t141));
    t144 = (~(t142));
    t145 = *((unsigned int *)t123);
    *((unsigned int *)t123) = (t145 & t143);
    t146 = *((unsigned int *)t123);
    *((unsigned int *)t123) = (t146 & t144);
    t147 = *((unsigned int *)t117);
    *((unsigned int *)t117) = (t147 & t143);
    t148 = *((unsigned int *)t117);
    *((unsigned int *)t117) = (t148 & t144);
    goto LAB46;

LAB47:    *((unsigned int *)t149) = 1;
    goto LAB50;

LAB49:    t156 = (t149 + 4);
    *((unsigned int *)t149) = 1;
    *((unsigned int *)t156) = 1;
    goto LAB50;

LAB51:    t161 = (t0 + 784U);
    t162 = *((char **)t161);
    t161 = ((char*)((ng1)));
    memset(t163, 0, 8);
    t164 = (t162 + 4);
    t165 = (t161 + 4);
    t166 = *((unsigned int *)t162);
    t167 = *((unsigned int *)t161);
    t168 = (t166 ^ t167);
    t169 = *((unsigned int *)t164);
    t170 = *((unsigned int *)t165);
    t171 = (t169 ^ t170);
    t172 = (t168 | t171);
    t173 = *((unsigned int *)t164);
    t174 = *((unsigned int *)t165);
    t175 = (t173 | t174);
    t176 = (~(t175));
    t177 = (t172 & t176);
    if (t177 != 0)
        goto LAB55;

LAB54:    if (t175 != 0)
        goto LAB56;

LAB57:    memset(t179, 0, 8);
    t180 = (t163 + 4);
    t181 = *((unsigned int *)t180);
    t182 = (~(t181));
    t183 = *((unsigned int *)t163);
    t184 = (t183 & t182);
    t185 = (t184 & 1U);
    if (t185 != 0)
        goto LAB58;

LAB59:    if (*((unsigned int *)t180) != 0)
        goto LAB60;

LAB61:    t188 = *((unsigned int *)t149);
    t189 = *((unsigned int *)t179);
    t190 = (t188 & t189);
    *((unsigned int *)t187) = t190;
    t191 = (t149 + 4);
    t192 = (t179 + 4);
    t193 = (t187 + 4);
    t194 = *((unsigned int *)t191);
    t195 = *((unsigned int *)t192);
    t196 = (t194 | t195);
    *((unsigned int *)t193) = t196;
    t197 = *((unsigned int *)t193);
    t198 = (t197 != 0);
    if (t198 == 1)
        goto LAB62;

LAB63:
LAB64:    goto LAB53;

LAB55:    *((unsigned int *)t163) = 1;
    goto LAB57;

LAB56:    t178 = (t163 + 4);
    *((unsigned int *)t163) = 1;
    *((unsigned int *)t178) = 1;
    goto LAB57;

LAB58:    *((unsigned int *)t179) = 1;
    goto LAB61;

LAB60:    t186 = (t179 + 4);
    *((unsigned int *)t179) = 1;
    *((unsigned int *)t186) = 1;
    goto LAB61;

LAB62:    t199 = *((unsigned int *)t187);
    t200 = *((unsigned int *)t193);
    *((unsigned int *)t187) = (t199 | t200);
    t201 = (t149 + 4);
    t202 = (t179 + 4);
    t203 = *((unsigned int *)t149);
    t204 = (~(t203));
    t205 = *((unsigned int *)t201);
    t206 = (~(t205));
    t207 = *((unsigned int *)t179);
    t208 = (~(t207));
    t209 = *((unsigned int *)t202);
    t210 = (~(t209));
    t211 = (t204 & t206);
    t212 = (t208 & t210);
    t213 = (~(t211));
    t214 = (~(t212));
    t215 = *((unsigned int *)t193);
    *((unsigned int *)t193) = (t215 & t213);
    t216 = *((unsigned int *)t193);
    *((unsigned int *)t193) = (t216 & t214);
    t217 = *((unsigned int *)t187);
    *((unsigned int *)t187) = (t217 & t213);
    t218 = *((unsigned int *)t187);
    *((unsigned int *)t187) = (t218 & t214);
    goto LAB64;

LAB65:    xsi_set_current_line(40, ng0);
    t225 = ((char*)((ng2)));
    t226 = (t0 + 1288);
    xsi_vlogvar_assign_value(t226, t225, 0, 0, 1);
    goto LAB67;

}


extern void work_m_00000000001918617334_1452706411_init()
{
	static char *pe[] = {(void *)Cont_30_0,(void *)Initial_31_1,(void *)Always_35_2};
	xsi_register_didat("work_m_00000000001918617334_1452706411", "isim/test1_isim_beh.exe.sim/work/m_00000000001918617334_1452706411.didat");
	xsi_register_executes(pe);
}
