/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x8ef4fb42 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "F:/verilog/P5_new/stall.v";
static int ng1[] = {0, 0};
static int ng2[] = {1, 0};



static void Cont_30_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 1812U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(30, ng0);
    t2 = (t0 + 1288);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = (t0 + 2348);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 40U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 1U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 0);
    t18 = (t0 + 2296);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Initial_31_1(char *t0)
{
    char *t1;
    char *t2;

LAB0:    xsi_set_current_line(32, ng0);

LAB2:    xsi_set_current_line(33, ng0);
    t1 = ((char*)((ng1)));
    t2 = (t0 + 1288);
    xsi_vlogvar_assign_value(t2, t1, 0, 0, 1);

LAB1:    return;
}

static void Always_35_2(char *t0)
{
    char t4[8];
    char t8[8];
    char t9[8];
    char t10[8];
    char t25[8];
    char t40[8];
    char t56[8];
    char t71[8];
    char t79[8];
    char t107[8];
    char t115[8];
    char t147[8];
    char t161[8];
    char t177[8];
    char t185[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t7;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    char *t17;
    char *t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    char *t24;
    char *t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    char *t39;
    char *t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    char *t47;
    char *t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    char *t53;
    char *t54;
    char *t55;
    char *t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    unsigned int t68;
    unsigned int t69;
    char *t70;
    char *t72;
    unsigned int t73;
    unsigned int t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    char *t78;
    unsigned int t80;
    unsigned int t81;
    unsigned int t82;
    char *t83;
    char *t84;
    char *t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    char *t93;
    char *t94;
    unsigned int t95;
    unsigned int t96;
    unsigned int t97;
    int t98;
    unsigned int t99;
    unsigned int t100;
    unsigned int t101;
    int t102;
    unsigned int t103;
    unsigned int t104;
    unsigned int t105;
    unsigned int t106;
    char *t108;
    unsigned int t109;
    unsigned int t110;
    unsigned int t111;
    unsigned int t112;
    unsigned int t113;
    char *t114;
    unsigned int t116;
    unsigned int t117;
    unsigned int t118;
    char *t119;
    char *t120;
    char *t121;
    unsigned int t122;
    unsigned int t123;
    unsigned int t124;
    unsigned int t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    char *t129;
    char *t130;
    unsigned int t131;
    unsigned int t132;
    unsigned int t133;
    unsigned int t134;
    unsigned int t135;
    unsigned int t136;
    unsigned int t137;
    unsigned int t138;
    int t139;
    int t140;
    unsigned int t141;
    unsigned int t142;
    unsigned int t143;
    unsigned int t144;
    unsigned int t145;
    unsigned int t146;
    char *t148;
    unsigned int t149;
    unsigned int t150;
    unsigned int t151;
    unsigned int t152;
    unsigned int t153;
    char *t154;
    char *t155;
    unsigned int t156;
    unsigned int t157;
    unsigned int t158;
    char *t159;
    char *t160;
    char *t162;
    char *t163;
    unsigned int t164;
    unsigned int t165;
    unsigned int t166;
    unsigned int t167;
    unsigned int t168;
    unsigned int t169;
    unsigned int t170;
    unsigned int t171;
    unsigned int t172;
    unsigned int t173;
    unsigned int t174;
    unsigned int t175;
    char *t176;
    char *t178;
    unsigned int t179;
    unsigned int t180;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    char *t184;
    unsigned int t186;
    unsigned int t187;
    unsigned int t188;
    char *t189;
    char *t190;
    char *t191;
    unsigned int t192;
    unsigned int t193;
    unsigned int t194;
    unsigned int t195;
    unsigned int t196;
    unsigned int t197;
    unsigned int t198;
    char *t199;
    char *t200;
    unsigned int t201;
    unsigned int t202;
    unsigned int t203;
    unsigned int t204;
    unsigned int t205;
    unsigned int t206;
    unsigned int t207;
    unsigned int t208;
    int t209;
    int t210;
    unsigned int t211;
    unsigned int t212;
    unsigned int t213;
    unsigned int t214;
    unsigned int t215;
    unsigned int t216;
    char *t217;
    unsigned int t218;
    unsigned int t219;
    unsigned int t220;
    unsigned int t221;
    unsigned int t222;
    char *t223;
    char *t224;

LAB0:    t1 = (t0 + 2100U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(35, ng0);
    t2 = (t0 + 2304);
    *((int *)t2) = 1;
    t3 = (t0 + 2128);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(36, ng0);

LAB5:    xsi_set_current_line(40, ng0);
    t5 = (t0 + 600U);
    t6 = *((char **)t5);
    t5 = (t0 + 692U);
    t7 = *((char **)t5);
    memset(t8, 0, 8);
    xsi_vlog_unsigned_minus(t8, 2, t6, 2, t7, 2);
    xsi_vlogtype_sign_extend(t4, 32, t8, 2);
    t5 = ((char*)((ng1)));
    memset(t9, 0, 8);
    xsi_vlog_signed_greater(t9, 32, t4, 32, t5, 32);
    memset(t10, 0, 8);
    t11 = (t9 + 4);
    t12 = *((unsigned int *)t11);
    t13 = (~(t12));
    t14 = *((unsigned int *)t9);
    t15 = (t14 & t13);
    t16 = (t15 & 1U);
    if (t16 != 0)
        goto LAB6;

LAB7:    if (*((unsigned int *)t11) != 0)
        goto LAB8;

LAB9:    t18 = (t10 + 4);
    t19 = *((unsigned int *)t10);
    t20 = *((unsigned int *)t18);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB10;

LAB11:    memcpy(t115, t10, 8);

LAB12:    memset(t147, 0, 8);
    t148 = (t115 + 4);
    t149 = *((unsigned int *)t148);
    t150 = (~(t149));
    t151 = *((unsigned int *)t115);
    t152 = (t151 & t150);
    t153 = (t152 & 1U);
    if (t153 != 0)
        goto LAB42;

LAB43:    if (*((unsigned int *)t148) != 0)
        goto LAB44;

LAB45:    t155 = (t147 + 4);
    t156 = *((unsigned int *)t147);
    t157 = *((unsigned int *)t155);
    t158 = (t156 || t157);
    if (t158 > 0)
        goto LAB46;

LAB47:    memcpy(t185, t147, 8);

LAB48:    t217 = (t185 + 4);
    t218 = *((unsigned int *)t217);
    t219 = (~(t218));
    t220 = *((unsigned int *)t185);
    t221 = (t220 & t219);
    t222 = (t221 != 0);
    if (t222 > 0)
        goto LAB60;

LAB61:    xsi_set_current_line(42, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1288);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 1);

LAB62:    goto LAB2;

LAB6:    *((unsigned int *)t10) = 1;
    goto LAB9;

LAB8:    t17 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t17) = 1;
    goto LAB9;

LAB10:    t22 = (t0 + 784U);
    t23 = *((char **)t22);
    t22 = (t0 + 968U);
    t24 = *((char **)t22);
    memset(t25, 0, 8);
    t22 = (t23 + 4);
    t26 = (t24 + 4);
    t27 = *((unsigned int *)t23);
    t28 = *((unsigned int *)t24);
    t29 = (t27 ^ t28);
    t30 = *((unsigned int *)t22);
    t31 = *((unsigned int *)t26);
    t32 = (t30 ^ t31);
    t33 = (t29 | t32);
    t34 = *((unsigned int *)t22);
    t35 = *((unsigned int *)t26);
    t36 = (t34 | t35);
    t37 = (~(t36));
    t38 = (t33 & t37);
    if (t38 != 0)
        goto LAB16;

LAB13:    if (t36 != 0)
        goto LAB15;

LAB14:    *((unsigned int *)t25) = 1;

LAB16:    memset(t40, 0, 8);
    t41 = (t25 + 4);
    t42 = *((unsigned int *)t41);
    t43 = (~(t42));
    t44 = *((unsigned int *)t25);
    t45 = (t44 & t43);
    t46 = (t45 & 1U);
    if (t46 != 0)
        goto LAB17;

LAB18:    if (*((unsigned int *)t41) != 0)
        goto LAB19;

LAB20:    t48 = (t40 + 4);
    t49 = *((unsigned int *)t40);
    t50 = (!(t49));
    t51 = *((unsigned int *)t48);
    t52 = (t50 || t51);
    if (t52 > 0)
        goto LAB21;

LAB22:    memcpy(t79, t40, 8);

LAB23:    memset(t107, 0, 8);
    t108 = (t79 + 4);
    t109 = *((unsigned int *)t108);
    t110 = (~(t109));
    t111 = *((unsigned int *)t79);
    t112 = (t111 & t110);
    t113 = (t112 & 1U);
    if (t113 != 0)
        goto LAB35;

LAB36:    if (*((unsigned int *)t108) != 0)
        goto LAB37;

LAB38:    t116 = *((unsigned int *)t10);
    t117 = *((unsigned int *)t107);
    t118 = (t116 & t117);
    *((unsigned int *)t115) = t118;
    t119 = (t10 + 4);
    t120 = (t107 + 4);
    t121 = (t115 + 4);
    t122 = *((unsigned int *)t119);
    t123 = *((unsigned int *)t120);
    t124 = (t122 | t123);
    *((unsigned int *)t121) = t124;
    t125 = *((unsigned int *)t121);
    t126 = (t125 != 0);
    if (t126 == 1)
        goto LAB39;

LAB40:
LAB41:    goto LAB12;

LAB15:    t39 = (t25 + 4);
    *((unsigned int *)t25) = 1;
    *((unsigned int *)t39) = 1;
    goto LAB16;

LAB17:    *((unsigned int *)t40) = 1;
    goto LAB20;

LAB19:    t47 = (t40 + 4);
    *((unsigned int *)t40) = 1;
    *((unsigned int *)t47) = 1;
    goto LAB20;

LAB21:    t53 = (t0 + 784U);
    t54 = *((char **)t53);
    t53 = (t0 + 876U);
    t55 = *((char **)t53);
    memset(t56, 0, 8);
    t53 = (t54 + 4);
    t57 = (t55 + 4);
    t58 = *((unsigned int *)t54);
    t59 = *((unsigned int *)t55);
    t60 = (t58 ^ t59);
    t61 = *((unsigned int *)t53);
    t62 = *((unsigned int *)t57);
    t63 = (t61 ^ t62);
    t64 = (t60 | t63);
    t65 = *((unsigned int *)t53);
    t66 = *((unsigned int *)t57);
    t67 = (t65 | t66);
    t68 = (~(t67));
    t69 = (t64 & t68);
    if (t69 != 0)
        goto LAB27;

LAB24:    if (t67 != 0)
        goto LAB26;

LAB25:    *((unsigned int *)t56) = 1;

LAB27:    memset(t71, 0, 8);
    t72 = (t56 + 4);
    t73 = *((unsigned int *)t72);
    t74 = (~(t73));
    t75 = *((unsigned int *)t56);
    t76 = (t75 & t74);
    t77 = (t76 & 1U);
    if (t77 != 0)
        goto LAB28;

LAB29:    if (*((unsigned int *)t72) != 0)
        goto LAB30;

LAB31:    t80 = *((unsigned int *)t40);
    t81 = *((unsigned int *)t71);
    t82 = (t80 | t81);
    *((unsigned int *)t79) = t82;
    t83 = (t40 + 4);
    t84 = (t71 + 4);
    t85 = (t79 + 4);
    t86 = *((unsigned int *)t83);
    t87 = *((unsigned int *)t84);
    t88 = (t86 | t87);
    *((unsigned int *)t85) = t88;
    t89 = *((unsigned int *)t85);
    t90 = (t89 != 0);
    if (t90 == 1)
        goto LAB32;

LAB33:
LAB34:    goto LAB23;

LAB26:    t70 = (t56 + 4);
    *((unsigned int *)t56) = 1;
    *((unsigned int *)t70) = 1;
    goto LAB27;

LAB28:    *((unsigned int *)t71) = 1;
    goto LAB31;

LAB30:    t78 = (t71 + 4);
    *((unsigned int *)t71) = 1;
    *((unsigned int *)t78) = 1;
    goto LAB31;

LAB32:    t91 = *((unsigned int *)t79);
    t92 = *((unsigned int *)t85);
    *((unsigned int *)t79) = (t91 | t92);
    t93 = (t40 + 4);
    t94 = (t71 + 4);
    t95 = *((unsigned int *)t93);
    t96 = (~(t95));
    t97 = *((unsigned int *)t40);
    t98 = (t97 & t96);
    t99 = *((unsigned int *)t94);
    t100 = (~(t99));
    t101 = *((unsigned int *)t71);
    t102 = (t101 & t100);
    t103 = (~(t98));
    t104 = (~(t102));
    t105 = *((unsigned int *)t85);
    *((unsigned int *)t85) = (t105 & t103);
    t106 = *((unsigned int *)t85);
    *((unsigned int *)t85) = (t106 & t104);
    goto LAB34;

LAB35:    *((unsigned int *)t107) = 1;
    goto LAB38;

LAB37:    t114 = (t107 + 4);
    *((unsigned int *)t107) = 1;
    *((unsigned int *)t114) = 1;
    goto LAB38;

LAB39:    t127 = *((unsigned int *)t115);
    t128 = *((unsigned int *)t121);
    *((unsigned int *)t115) = (t127 | t128);
    t129 = (t10 + 4);
    t130 = (t107 + 4);
    t131 = *((unsigned int *)t10);
    t132 = (~(t131));
    t133 = *((unsigned int *)t129);
    t134 = (~(t133));
    t135 = *((unsigned int *)t107);
    t136 = (~(t135));
    t137 = *((unsigned int *)t130);
    t138 = (~(t137));
    t139 = (t132 & t134);
    t140 = (t136 & t138);
    t141 = (~(t139));
    t142 = (~(t140));
    t143 = *((unsigned int *)t121);
    *((unsigned int *)t121) = (t143 & t141);
    t144 = *((unsigned int *)t121);
    *((unsigned int *)t121) = (t144 & t142);
    t145 = *((unsigned int *)t115);
    *((unsigned int *)t115) = (t145 & t141);
    t146 = *((unsigned int *)t115);
    *((unsigned int *)t115) = (t146 & t142);
    goto LAB41;

LAB42:    *((unsigned int *)t147) = 1;
    goto LAB45;

LAB44:    t154 = (t147 + 4);
    *((unsigned int *)t147) = 1;
    *((unsigned int *)t154) = 1;
    goto LAB45;

LAB46:    t159 = (t0 + 784U);
    t160 = *((char **)t159);
    t159 = ((char*)((ng1)));
    memset(t161, 0, 8);
    t162 = (t160 + 4);
    t163 = (t159 + 4);
    t164 = *((unsigned int *)t160);
    t165 = *((unsigned int *)t159);
    t166 = (t164 ^ t165);
    t167 = *((unsigned int *)t162);
    t168 = *((unsigned int *)t163);
    t169 = (t167 ^ t168);
    t170 = (t166 | t169);
    t171 = *((unsigned int *)t162);
    t172 = *((unsigned int *)t163);
    t173 = (t171 | t172);
    t174 = (~(t173));
    t175 = (t170 & t174);
    if (t175 != 0)
        goto LAB50;

LAB49:    if (t173 != 0)
        goto LAB51;

LAB52:    memset(t177, 0, 8);
    t178 = (t161 + 4);
    t179 = *((unsigned int *)t178);
    t180 = (~(t179));
    t181 = *((unsigned int *)t161);
    t182 = (t181 & t180);
    t183 = (t182 & 1U);
    if (t183 != 0)
        goto LAB53;

LAB54:    if (*((unsigned int *)t178) != 0)
        goto LAB55;

LAB56:    t186 = *((unsigned int *)t147);
    t187 = *((unsigned int *)t177);
    t188 = (t186 & t187);
    *((unsigned int *)t185) = t188;
    t189 = (t147 + 4);
    t190 = (t177 + 4);
    t191 = (t185 + 4);
    t192 = *((unsigned int *)t189);
    t193 = *((unsigned int *)t190);
    t194 = (t192 | t193);
    *((unsigned int *)t191) = t194;
    t195 = *((unsigned int *)t191);
    t196 = (t195 != 0);
    if (t196 == 1)
        goto LAB57;

LAB58:
LAB59:    goto LAB48;

LAB50:    *((unsigned int *)t161) = 1;
    goto LAB52;

LAB51:    t176 = (t161 + 4);
    *((unsigned int *)t161) = 1;
    *((unsigned int *)t176) = 1;
    goto LAB52;

LAB53:    *((unsigned int *)t177) = 1;
    goto LAB56;

LAB55:    t184 = (t177 + 4);
    *((unsigned int *)t177) = 1;
    *((unsigned int *)t184) = 1;
    goto LAB56;

LAB57:    t197 = *((unsigned int *)t185);
    t198 = *((unsigned int *)t191);
    *((unsigned int *)t185) = (t197 | t198);
    t199 = (t147 + 4);
    t200 = (t177 + 4);
    t201 = *((unsigned int *)t147);
    t202 = (~(t201));
    t203 = *((unsigned int *)t199);
    t204 = (~(t203));
    t205 = *((unsigned int *)t177);
    t206 = (~(t205));
    t207 = *((unsigned int *)t200);
    t208 = (~(t207));
    t209 = (t202 & t204);
    t210 = (t206 & t208);
    t211 = (~(t209));
    t212 = (~(t210));
    t213 = *((unsigned int *)t191);
    *((unsigned int *)t191) = (t213 & t211);
    t214 = *((unsigned int *)t191);
    *((unsigned int *)t191) = (t214 & t212);
    t215 = *((unsigned int *)t185);
    *((unsigned int *)t185) = (t215 & t211);
    t216 = *((unsigned int *)t185);
    *((unsigned int *)t185) = (t216 & t212);
    goto LAB59;

LAB60:    xsi_set_current_line(40, ng0);
    t223 = ((char*)((ng2)));
    t224 = (t0 + 1288);
    xsi_vlogvar_assign_value(t224, t223, 0, 0, 1);
    goto LAB62;

}


extern void work_m_00000000001918617334_1452706411_init()
{
	static char *pe[] = {(void *)Cont_30_0,(void *)Initial_31_1,(void *)Always_35_2};
	xsi_register_didat("work_m_00000000001918617334_1452706411", "isim/test1_isim_beh.exe.sim/work/m_00000000001918617334_1452706411.didat");
	xsi_register_executes(pe);
}
